const express = require("express");
const router = express.Router();
const { isAdminAuth } = require("../../middleware/checkAdmin.mdl");
const userRoutes = require("../user.routes");
const productRoutes = require("./products.routes");

router.use(isAdminAuth);

router.use("/user", userRoutes);
router.use("/product", productRoutes);

module.exports = router;
