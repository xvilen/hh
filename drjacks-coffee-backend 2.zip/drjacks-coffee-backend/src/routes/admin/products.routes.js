const express = require("express");
const router = express.Router();

const validate = require("../../validations/handler");
const rules = require("../../validations/product.validation");
const product = require("../../controller/v1/product");
const { handleImageFile } = require("../../services/multerService");
const { isAdminAuth } = require("../../middleware/checkAdmin.mdl");
const { isAdmin } = require("../../middleware/auth.mdl");

router.post("/add", isAdmin, isAdminAuth, handleImageFile, validate(rules.addProduct), product.create);

module.exports = router;
