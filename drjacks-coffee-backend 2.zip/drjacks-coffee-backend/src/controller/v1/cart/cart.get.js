const { Cart } = require("../../../models/cart.model");
const { Vendor } = require("../../../models/vendor.model");
const { Category } = require("../../../models/category.model"); // Import the Category model
const { Product } = require("../../../models/product.model");
const makeMongoDbService = require("../../../services/mongoDbService")({
  model: Cart,
});
const makeMongoDbServiceVendor = require("../../../services/mongoDbService")({
  model: Vendor,
});

const makeMongoDbServiceProduct = require("../../../services/mongoDbService");
({
  model: Product,
});
const { response, resMessage } = require("../../../helpers/common");

exports.get = async (req) => {
  try {
    const { _id } = req.user;

    // Fetch vendors with status not equal to "D"
    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });

    // Convert vendors array to an object with vendor IDs as keys
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    // Fetch the cart document for the user and populate cart items
    let result = await makeMongoDbService.getSingleDocumentByQueryPopulate(
      { user: _id },
      null,
      ["cartItems.product"]
    );

    // Check if result is null
    if (!result) {
      return response(
        false,
        resMessage.success,
        null,
        { id: null, user: _id, cartItems: [] },
        200
      );
    }

    let cartItems = [];
    for (let item of result.cartItems) {
      let { quantity, bean, product: productDetail } = item._doc;

      // Skip products with status "D"
      if (productDetail.status === "D") {
        continue;
      }

      if (productDetail.oldDetails && productDetail.oldDetails.status === "A") {
        if (productDetail.status === "A") {
          // Fetch only productDetail if both statuses are "A"
          productDetail = productDetail;
        } else {
          // Fetch oldDetails if productDetail's status is not "A"
          productDetail = productDetail.oldDetails;
        }
      } else if (productDetail.status === "P") {
        // Skip items with status "P" if oldDetails is not used
        continue;
      }

      // Fetch vendor details
      let vendor = vendors[productDetail.vendor];
      if (!vendor || vendor.status === "D") {
        vendor = { commission: 0 };
      }

      // Fetch category details
      const category = await Category.findById(productDetail.category);
      const categoryName = category ? category.name : "Unknown"; // Use "Unknown" if category is not found

      // Push processed cart item details to cartItems array
      cartItems.push({
        _id: productDetail._id,
        title: productDetail.title,
        description: productDetail.description,
        price: productDetail.price,
        total_price: productDetail.total_price,
        image: productDetail.image,
        status: productDetail.status,
        isSoldOut: productDetail.isSoldOut,
        weight: productDetail.weight,
        origins: productDetail.origins,
        missions: productDetail.missions,
        roast: productDetail.roast,
        bean: bean,
        vendor: {
          _id: vendor._id,
          first_name: vendor.first_name,
          last_name: vendor.last_name,
          email: vendor.email,
          password: vendor.password,
          commission: vendor.commission,
          status: vendor.status,
          phone_number: vendor.phone_number,
          address: vendor.address,
          taxId: vendor.taxId,
          image: vendor.image,
          display: vendor.display,
          website: vendor.website,
          id: vendor._id,
        },
        isAddedByAdmin: productDetail.isAddedByAdmin,
        extraAttr: productDetail.extraAttr,
        createdAt: productDetail.createdAt,
        updatedAt: productDetail.updatedAt,
        __v: productDetail.__v,
        markup_price: productDetail.markup_price,
        markup_type: productDetail.markup_type,
        quantity: quantity,
        finalPrice: quantity * productDetail.total_price,
        category: categoryName,
      });
    }

    // Prepare the final result
    const finalResult = {
      id: result.id,
      user: result.user,
      cartItems: cartItems,
    };

    return response(false, resMessage.success, null, finalResult, 200);
  } catch (error) {
    console.error(error);
    throw response(true, null, error.message, error.stack, 500);
  }
};
