const { Product } = require("../../../models/product.model");
const { Vendor } = require("../../../models/vendor.model");
const { sendEmail } = require("../../../services/email");
const makeMongoDbService = require("../../../services/mongoDbService")({
  model: Product,
});
const makeMongoDbServiceVendor = require("../../../services/mongoDbService")({
  model: Vendor,
});
const { response, resMessage } = require("../../../helpers/common");


// Create and Save a new product
exports.create = async (req) => {
  try {
    if (req?.user?.isAdmin) {
      req.body.vendor = req.user._id;
      req.body.isAddedByAdmin = true;
      req.body.status = "A";
    }

    if (req?.vendor?._id) {
      req.body.vendor = req.vendor._id;
    }

    console.log("Before split:", req.body.bean);
    if (req.body.bean && typeof req.body.bean === "string") {
      req.body.bean = req.body.bean.split(",");
    }
    console.log("After split:", req.body.bean);
    req.body.total_price = req.body.price;
    if (req.body.markup_price !== undefined && req.body.markup_type !== undefined) {
      // If provided, update markup_price and markup_type fields of the product data
      req.body.markup_price = parseFloat(req.body.markup_price);
      // eslint-disable-next-line no-self-assign
      req.body.markup_type = req.body.markup_type;

      // Calculate total_price based on markup_type and markup_price
      if (req.body.markup_type === "Flat") {
        req.body.total_price = Number(req.body.price) + Number(req.body.markup_price);
      } else if (req.body.markup_type === "Percentage") {
        const markupAmount = (Number(req.body.price) * Number(req.body.markup_price)) / 100;
        req.body.total_price = Number(req.body.price) + Number(markupAmount);
      }
    } else if (req.body.price != undefined) {
      if (req.body.markup_type === "Flat") {
        req.body.total_price =
          parseFloat(req.body.price) + parseFloat(req.body.markup_price);
      } else if (req.body.markup_type === "Percentage") {
        const markupAmount =
          (parseFloat(req.body.price) * parseFloat(req.body.markup_price)) /
          100;
          req.body.total_price = Number(req.body.price) + Number(markupAmount);
      }
    }
    let newProduct = await makeMongoDbService.createDocument(req.body);
    // newProduct.oldDetails = {...newProduct._doc};
    // const updatedProduct = await makeMongoDbService.findOneAndUpdateDocument(
    //   { _id: newProduct._id },
    //   newProduct
    // );
    if (req?.vendor?._id) {
      const vendorDetails =
        await makeMongoDbServiceVendor.getSingleDocumentById(req?.vendor?._id);
        const message = getPendingApprovalMessage(newProduct, vendorDetails);
        await sendEmail("", "[Dr Jack's] New Product Approval Pending", message);
    }

    return response(false, resMessage.success, null, newProduct, 201);
  } catch (error) {
    console.log(error);
    throw response(true, null, error.message, error.stack, 500);
  }
};

function getPendingApprovalMessage(product, vendor) {
  return `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>FeedBack Message</title>
    </head>
    
    <body>
      <section>
        <div class="companyLogo">
          <img src="https://drjacks.coffee/static/media/logo.caf7bd2d66fa6b49d6b2.png"/ width="10%">
        </div>
        <div>
        <p>A new product has been added by a vendor and is currently pending your approval.</p>
          <table style="width: 500px">
            <tr>
              <td>
                <p style="font-weight: 600; margin: 0; ">
                Product Name:
                </p>
                </td>
                <td>
              <p style="margin: 0;">${product.title}</p>
            </td>
            </tr>
            <tr>
            <td>
              <p style="font-weight: 600; margin: 0; ">
              Vendor Name:
              </p>
            </td>
            <td>
              <p>${vendor.first_name} ${vendor.last_name}</p>
            </td>
          </tr>
          <tr>
            <td>
              <p style="font-weight: 600; margin: 0;">
              Description:
              </p>
            </td>
            <td><p style="margin: 0; ">${product.description}</p></td>
          </tr>
          <tr>
            <td>
              <p style="font-weight: 600; margin: 0;">
              Price:
              </p>
            </td>
            <td><p style="margin: 0; ">$ ${product.price}</p></td>
          </tr>
          </table>
          <p>Please review the product and take necessary action.</p>
          </div>
      
    </section>
  </body>
</html>
`;
}

exports.uploadImages = async (req) => {
  console.log(req.body);
  return response(false, resMessage.success, null, req.body, 201)
}

// function getPendingApprovalMessage(product, vendor) {
//   return `
// 		A new product has been added by a vendor and is currently pending your approval.
//     <br><br>
//     Product Details: <br>
//     - Product Title: ${product.title} <br>
//     - Vendor Name: ${vendor.first_name} ${vendor.last_name} <br>
//     - Description: ${product.description} <br>
//     - Price: $ ${product.price} <br>
//     <br><br>
//     Please review the product and take necessary action.
// 	`;
// }
