const Feedback = require("../../../models/feedback.model");
const makeMongoDbService = require("../../../services/mongoDbService")({
  model: Feedback,
});
const { sendEmail } = require("../../../services/email");
const { response, resMessage } = require("../../../helpers/common");

exports.add = async (req) => {
  try {
    const feedback = await makeMongoDbService.createDocument(req.body);
    const message = getFeedbackMessage(req.body);
    await sendEmail(
      "drjacks@obu.edu",
      "[Dr Jack's] New user feedback",
      message
    ); // Updated email address
    return response(false, resMessage.success, null, feedback, 201);
  } catch (error) {
    console.log(error);
    throw response(true, null, error.message, error.stack, 500);
  }
};

// function getFeedbackMessage({ name, email, message }) {
//   return `
// 		A new message is submitted. Please find the details below:
//     <br><br>
//     - Name: ${name} <br>
//     - Email: ${email} <br>
//     - Message: ${message} <br>
// 	`;
// }
function getFeedbackMessage({ name, email, message }) {
  return `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>FeedBack Message</title>
    </head>
    
    <body>
      <section>
        <div class="companyLogo">
          <img src="https://drjacks.coffee/static/media/logo.caf7bd2d66fa6b49d6b2.png"/ width="10%">
        </div>
        <div>
          <table style="width: 500px">
            <tr>
              <td style="width: 15%;">
                <p style="font-weight: 600; margin: 0; ">
                NAME:
                </p>
                </td>
                <td>
              <p style="margin: 0;">${name}</p>
            </td>
            </tr>
            <tr>
            <td style="width: 15%;">
              <p style="font-weight: 600; margin: 0; ">
                E-MAIL:
              </p>
            </td>
            <td>
              <a
                href="javascript:void(0)"
                style="margin: 0;"
                >${email}</a
              >
            </td>
          </tr>
          <tr>
            <td style="width: 15%;">
              <p style="font-weight: 600; margin: 0;">
              Message:
              </p>
            </td>
            <td><p style="margin: 0; ">${message}</p></td>
          </tr>
          </table>
          </div>
      
    </section>
  </body>
</html>
  `;
}
