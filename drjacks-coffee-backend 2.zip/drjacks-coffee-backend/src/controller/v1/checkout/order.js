const { Order } = require("../../../models/order.model");
const { User } = require("../../../models/user.model");
const makeMongoDbService = require("../../../services/mongoDbService")({
  model: Order,
});
const makeMongoDbServiceUser = require("../../../services/mongoDbService")({
  model: User,
});
const { Product } = require("../../../models/product.model");
const { Vendor } = require("../../../models/vendor.model");
const makeMongoDbServiceProduct = require("../../../services/mongoDbService")({
  model: Product,
});
const makeMongoDbServiceVendor = require("../../../services/mongoDbService")({
  model: Vendor,
});
const { response, resMessage } = require("../../../helpers/common");
const { default: mongoose } = require("mongoose");
const {
  sendEmail,
  sendEmailWithAttachment,
} = require("../../../services/email");
//const moment = require('moment');
const moment = require("moment");

const unitShippingCost_firstProduct = 6;
const unitShippingCost_nextProducts = 2;

exports.get = async (req) => {
  try {
    let meta = {};
    const pageNumber = parseInt(req.query.pageNumber);
    if (isNaN(pageNumber) || pageNumber < 1) {
      throw new Error("Invalid pageNumber");
    }
    const pageSize = 10;
    const skip = pageNumber === 1 ? 0 : parseInt((pageNumber - 1) * pageSize);
    const sortCriteria = { _id: -1 };
    let searchValue = req.query.search || "";
    let orderCount = 0;
    let result = {};
    let matchCondition = {
      $and: [{ status: { $ne: "D" } }],
    };

    // if (searchValue && searchValue.trim() !== "") {
    //   matchCondition["$and"].push({
    //     $or: [
    //       { payment_status: { $regex: searchValue, $options: "i" } },
    //       { status: { $regex: searchValue, $options: "i" } },
    //       { vendorNames: { $regex: searchValue, $options: "i" } },
    //       { vendors: { $regex: searchValue, $options:"i" } },
    //     ],
    //   });
    // }

    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    let users = await makeMongoDbServiceUser.getDocumentByQuery({
      // Add any conditions here if needed
    });
    users = users.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    if (req.user && req.isAdmin === true) {
      if (req.query.order_id && req.query.order_id !== "") {
        matchCondition["$and"].push({
          _id: new mongoose.Types.ObjectId(req.query.order_id),
        });
      }
      result = await makeMongoDbService.getDocumentByCustomAggregation([
        { $match: matchCondition },
        { $sort: sortCriteria },
        // { $skip: skip },
        // { $limit: pageSize },
      ]);
      orderCount = await makeMongoDbService.getCountDocumentByQuery(
        matchCondition
      );

      meta = {
        pageNumber,
        pageSize,
        totalCount: orderCount,
        prevPage: parseInt(pageNumber) === 1 ? false : true,
        nextPage:
          parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
            ? false
            : true,
        totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
      };
    } else if (req.isVendor === true) {
      if (req.query.order_id && req.query.order_id !== "") {
        matchCondition["$and"].push(
          {
            _id: new mongoose.Types.ObjectId(req.query.order_id),
          },
          {
            vendors: { $in: [req.vendor._id] },
          }
        );
      } else {
        matchCondition["$and"].push({
          vendors: { $in: [req.vendor._id] },
        });
      }
      result = await makeMongoDbService.getDocumentByCustomAggregation([
        { $match: matchCondition },
        { $sort: sortCriteria },
        // { $skip: skip },
        // { $limit: pageSize },
      ]);
      orderCount = await makeMongoDbService.getCountDocumentByQuery(
        matchCondition
      );

      result = result.map((order) => {
        const filteredOrder = { ...order };
        const filteredProducts = order.accounting.cartAccountingList.filter(
          (product) => product.vendorId.toString() == req.vendor._id
        );
        let totalPrice = 0;
        let totalItems = 0;
        for (let product of filteredProducts) {
          totalPrice += product.totalPrice;
          totalItems += product.quantity;
        }

        // in this case as we have only one vendor so we can calculate as below
        const totalShippingCost =
          totalItems.length <= 1
            ? totalItems * unitShippingCost_firstProduct
            : unitShippingCost_firstProduct +
              (totalItems - 1) * unitShippingCost_nextProducts;
        totalPrice += totalShippingCost;

        filteredOrder.accounting.cartAccountingList = filteredProducts;
        filteredOrder.vendorNames = filteredOrder.vendorNames
          ? filteredOrder.vendorNames.map((name) => {
              let arr = name.split(" ");
              // Remove undefined and other non-name parts (like vendor ID)
              arr = arr.filter(
                (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
              );
              return arr.join(" ");
            })
          : [];

        filteredOrder.accounting.shippingCost = totalShippingCost;
        filteredOrder.accounting.finalTotal = totalPrice;
        return filteredOrder;
      });
      meta = {
        pageNumber,
        pageSize,
        totalCount: orderCount,
        prevPage: parseInt(pageNumber) === 1 ? false : true,
        nextPage:
          parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
            ? false
            : true,
        totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
      };
    } else {
      if (req.query.order_id && req.query.order_id !== "") {
        matchCondition["$and"].push(
          {
            _id: new mongoose.Types.ObjectId(req.query.order_id),
          },
          {
            user_id: req.user ? req.user._id : req.vendor._id,
          }
        );
      } else {
        matchCondition["$and"].push({
          user_id: req.user ? req.user._id : req.vendor._id,
        });
      }
      result = await makeMongoDbService.getDocumentByCustomAggregation([
        {
          $match: matchCondition,
        },
        { $sort: sortCriteria },
        // { $skip: skip },
        // { $limit: pageSize },
      ]);
      orderCount = await makeMongoDbService.getCountDocumentByQuery(
        matchCondition
      );

      meta = {
        pageNumber,
        pageSize,
        totalCount: orderCount,
        prevPage: parseInt(pageNumber) === 1 ? false : true,
        nextPage:
          parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
            ? false
            : true,
        totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
      };
    }

    result = result.map((order) => {
      const filteredOrder = { ...order };
      const userDetails = users[order.user_id.toString()]; // Fetch userDetails based on user_id
      filteredOrder.accounting.cartAccountingList =
        order.accounting.cartAccountingList.map((product) => {
          // console.log(product);
          const productDetails = products[product.productId.toString()];
          const vendorDetails = vendors[product.vendorId.toString()];

          return {
            ...product,
            productDetails: !productDetails ? {} : productDetails,
            vendorDetails: !vendorDetails ? {} : vendorDetails,
          };
        });
      filteredOrder.userDetails = !userDetails ? {} : userDetails;
      return filteredOrder;
    });

    if (searchValue && searchValue.trim() !== "") {
      searchValue = searchValue.toString().toLowerCase();
      console.log(searchValue);
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }

    meta.totalCount = result.length;
    meta.nextPage =
      parseInt(result.length) / parseInt(pageSize) <= parseInt(pageNumber)
        ? false
        : true;
    meta.totalPages = Math.ceil(parseInt(result.length) / parseInt(pageSize));

    result = result.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);
    const userDetails = result.length > 0 ? result[0].userDetails : {};

    return response(
      false,
      null,
      resMessage.success,
      {
        result,
        meta,
        userDetails,
        // userDetails: req.user,
      },
      200
    );
  } catch (error) {
    console.log(error);
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.getPaid = async (req) => {
  try {
    let meta = {};
    const pageNumber = parseInt(req.query.pageNumber);
    if (isNaN(pageNumber) || pageNumber < 1) {
      throw new Error("Invalid pageNumber");
    }
    const pageSize = 10;
    const skip = pageNumber === 1 ? 0 : parseInt((pageNumber - 1) * pageSize);
    const sortCriteria = { _id: -1 };
    let searchValue = req.query.search || "";
    let orderCount = 0;
    let result = {};
    let matchCondition = {
      $and: [
        { status: "PC" }, // Filter orders with status 'PF' (payment failed)
      ],
    };
    console.log(req.isVendor);
    console.log(req.isAdmin);
    // Ensure the request is from a vendor or admin and fetch vendor ID from the token
    if (!req.isVendor && !req.isAdmin) {
      return response(
        true,
        "User unauthorised to perform this action",
        "",
        null,
        403
      );
    }

    if (req.isVendor) {
      // Add condition to filter orders by the vendor ID
      matchCondition.$and.push({ vendors: req.vendor._id });
    }
    // if (searchValue && searchValue.trim() !== "") {
    //   matchCondition["$and"].push({
    //     $or: [
    //       { payment_status: { $regex: searchValue, $options: "i" } },
    //       { status: { $regex: searchValue, $options: "i" } },
    //       { vendorNames: { $regex: searchValue, $options: "i" } },
    //     ],
    //   });
    // }

    // Fetch products and vendors for further processing
    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    // Fetch orders based on the defined conditions
    result = await makeMongoDbService.getDocumentByCustomAggregation([
      { $match: matchCondition },
      { $sort: sortCriteria },
      //   { $skip: skip },
      //   { $limit: pageSize },
    ]);
    console.log(result);
    // Get total order count
    orderCount = await makeMongoDbService.getCountDocumentByQuery(
      matchCondition
    );

    result = result.map((order) => {
      const filteredOrder = { ...order };
      let filteredProducts = order.accounting.cartAccountingList;
      if (req.isVendor) {
        filteredProducts = order.accounting.cartAccountingList.filter(
          (product) => product.vendorId.toString() == req.vendor._id.toString()
        );
      }
      let totalPrice = 0;
      let totalItems = 0;
      for (let product of filteredProducts) {
        totalPrice += product.totalPrice;
        totalItems += product.quantity;
      }

      let totalShippingCost = order.accounting.shippingCost;
      if (req.isVendor) {
        // in this case as we have only one vendor so we can calculate as below
        totalShippingCost =
          totalItems <= 1
            ? totalItems * unitShippingCost_firstProduct
            : unitShippingCost_firstProduct +
              (totalItems - 1) * unitShippingCost_nextProducts;
      }
      totalPrice += totalShippingCost;

      filteredOrder.accounting.cartAccountingList = filteredProducts;
      filteredOrder.vendorNames = filteredOrder.vendorNames
        ? filteredOrder.vendorNames.map((name) => {
            let arr = name.split(" ");
            // Remove undefined and other non-name parts (like vendor ID)
            arr = arr.filter(
              (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
            );
            return arr.join(" ");
          })
        : [];

      filteredOrder.accounting.shippingCost = totalShippingCost;
      filteredOrder.accounting.finalTotal = totalPrice;
      return filteredOrder;
    });

    // Construct meta data for pagination
    meta = {
      pageNumber,
      pageSize,
      totalCount: orderCount,
      prevPage: parseInt(pageNumber) === 1 ? false : true,
      nextPage:
        parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
          ? false
          : true,
      totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
    };

    // Map products and vendors to orders and fetch user details
    result = await Promise.all(
      result.map(async (order) => {
        const filteredOrder = { ...order };
        filteredOrder.accounting.cartAccountingList =
          order.accounting.cartAccountingList.map((product) => {
            const productDetails = products[product.productId.toString()];
            const vendorDetails = vendors[product.vendorId.toString()];

            return {
              ...product,
              productDetails: !productDetails ? {} : productDetails,
              vendorDetails: !vendorDetails ? {} : vendorDetails,
            };
          });

        // Fetch user details by user_id
        const userDetails = await makeMongoDbServiceUser.getDocumentById(
          order.user_id
        );
        filteredOrder.userDetails = userDetails || {}; // Include user details in the order
        return filteredOrder;
      })
    );

    if (searchValue && searchValue.trim() !== "") {
      searchValue = searchValue.toString().toLowerCase();
      console.log(searchValue);
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          // console.log({vendor})
          // console.log()
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let vendor of order.vendors) {
          console.log(vendor);
          if (vendor.toString().toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }

    meta.totalCount = result.length;
    meta.nextPage =
      parseInt(result.length) / parseInt(pageSize) <= parseInt(pageNumber)
        ? false
        : true;
    meta.totalPages = Math.ceil(parseInt(result.length) / parseInt(pageSize));

    result = result.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);

    // Return response with orders, meta data, and user details
    return response(
      false,
      null,
      resMessage.success,
      {
        result,
        meta,
        userDetails: req.isVendor ? req.vendor : req.user, // Include vendor details as well
      },
      200
    );
  } catch (error) {
    // Handle errors
    console.log(error);
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.getShipped = async (req) => {
  try {
    let meta = {};
    const pageNumber = parseInt(req.query.pageNumber);
    if (isNaN(pageNumber) || pageNumber < 1) {
      throw new Error("Invalid pageNumber");
    }
    const pageSize = 10;
    const skip = pageNumber === 1 ? 0 : parseInt((pageNumber - 1) * pageSize);
    const sortCriteria = { _id: -1 };
    let searchValue = req.query.search || "";
    let orderCount = 0;
    let result = {};
    let matchCondition = {
      $and: [
        { status: "S" }, // Filter orders with status 'PF' (payment failed)
      ],
    };
    console.log(req.isVendor);
    console.log(req.isAdmin);
    // Ensure the request is from a vendor or admin and fetch vendor ID from the token
    if (!req.isVendor && !req.isAdmin) {
      return response(
        true,
        "User unauthorised to perform this action",
        "",
        null,
        403
      );
    }

    if (req.isVendor) {
      // Add condition to filter orders by the vendor ID
      matchCondition.$and.push({ vendors: req.vendor._id });
    }
    // if (searchValue && searchValue.trim() !== "") {
    //   matchCondition["$and"].push({
    //     $or: [
    //       { payment_status: { $regex: searchValue, $options: "i" } },
    //       { status: { $regex: searchValue, $options: "i" } },
    //       { vendorNames: { $regex: searchValue, $options: "i" } },
    //     ],
    //   });
    // }

    // Fetch products and vendors for further processing
    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    // Fetch orders based on the defined conditions
    result = await makeMongoDbService.getDocumentByCustomAggregation([
      { $match: matchCondition },
      { $sort: sortCriteria },
      //   { $skip: skip },
      //   { $limit: pageSize },
    ]);
    console.log(result);
    // Get total order count
    orderCount = await makeMongoDbService.getCountDocumentByQuery(
      matchCondition
    );

    result = result.map((order) => {
      const filteredOrder = { ...order };
      let filteredProducts = order.accounting.cartAccountingList;
      if (req.isVendor) {
        filteredProducts = order.accounting.cartAccountingList.filter(
          (product) => product.vendorId.toString() == req.vendor._id.toString()
        );
      }
      let totalPrice = 0;
      let totalItems = 0;
      for (let product of filteredProducts) {
        totalPrice += product.totalPrice;
        totalItems += product.quantity;
      }

      let totalShippingCost = order.accounting.shippingCost;
      if (req.isVendor) {
        // in this case as we have only one vendor so we can calculate as below
        totalShippingCost =
          totalItems <= 1
            ? totalItems * unitShippingCost_firstProduct
            : unitShippingCost_firstProduct +
              (totalItems - 1) * unitShippingCost_nextProducts;
      }
      totalPrice += totalShippingCost;

      filteredOrder.accounting.cartAccountingList = filteredProducts;
      filteredOrder.vendorNames = filteredOrder.vendorNames
        ? filteredOrder.vendorNames.map((name) => {
            let arr = name.split(" ");
            // Remove undefined and other non-name parts (like vendor ID)
            arr = arr.filter(
              (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
            );
            return arr.join(" ");
          })
        : [];

      filteredOrder.accounting.shippingCost = totalShippingCost;
      filteredOrder.accounting.finalTotal = totalPrice;
      return filteredOrder;
    });

    // Construct meta data for pagination
    meta = {
      pageNumber,
      pageSize,
      totalCount: orderCount,
      prevPage: parseInt(pageNumber) === 1 ? false : true,
      nextPage:
        parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
          ? false
          : true,
      totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
    };

    // Map products and vendors to orders and fetch user details
    result = await Promise.all(
      result.map(async (order) => {
        const filteredOrder = { ...order };
        filteredOrder.accounting.cartAccountingList =
          order.accounting.cartAccountingList.map((product) => {
            const productDetails = products[product.productId.toString()];
            const vendorDetails = vendors[product.vendorId.toString()];
            return {
              ...product,
              productDetails: !productDetails ? {} : productDetails,
              vendorDetails: !vendorDetails ? {} : vendorDetails,
            };
          });

        // Fetch user details by user_id
        const userDetails = await makeMongoDbServiceUser.getDocumentById(
          order.user_id
        );
        filteredOrder.userDetails = userDetails || {}; // Include user details in the order
        return filteredOrder;
      })
    );

    if (searchValue && searchValue.trim() !== "") {
      searchValue = searchValue.toString().toLowerCase();
      console.log(searchValue);
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          // console.log({vendor})
          // console.log()
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let vendor of order.vendors) {
          if (vendor.toString().toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }

    meta.totalCount = result.length;
    meta.nextPage =
      parseInt(result.length) / parseInt(pageSize) <= parseInt(pageNumber)
        ? false
        : true;
    meta.totalPages = Math.ceil(parseInt(result.length) / parseInt(pageSize));

    result = result.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);

    // Return response with orders, meta data, and user details
    return response(
      false,
      null,
      resMessage.success,
      {
        result,
        meta,
        userDetails: req.isVendor ? req.vendor : req.user, // Include vendor details as well
      },
      200
    );
  } catch (error) {
    // Handle errors
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.getCancel = async (req) => {
  try {
    let meta = {};
    const pageNumber = parseInt(req.query.pageNumber);
    if (isNaN(pageNumber) || pageNumber < 1) {
      throw new Error("Invalid pageNumber");
    }
    const pageSize = 10;
    const skip = pageNumber === 1 ? 0 : parseInt((pageNumber - 1) * pageSize);
    const sortCriteria = { _id: -1 };
    let searchValue = req.query.search || "";
    let orderCount = 0;
    let result = {};
    let matchCondition = {
      $and: [
        { status: "CL" }, // Filter orders with status 'PF' (payment failed)
      ],
    };
    console.log(req.isVendor);
    console.log(req.isAdmin);
    // Ensure the request is from a vendor or admin and fetch vendor ID from the token
    if (!req.isVendor && !req.isAdmin) {
      return response(
        true,
        "User unauthorised to perform this action",
        "",
        null,
        403
      );
    }

    if (req.isVendor) {
      // Add condition to filter orders by the vendor ID
      matchCondition.$and.push({ vendors: req.vendor._id });
    }
    // if (searchValue && searchValue.trim() !== "") {
    //   matchCondition["$and"].push({
    //     $or: [
    //       { payment_status: { $regex: searchValue, $options: "i" } },
    //       { status: { $regex: searchValue, $options: "i" } },
    //       { vendorNames: { $regex: searchValue, $options: "i" } },
    //     ],
    //   });
    // }

    // Fetch products and vendors for further processing
    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    // Fetch orders based on the defined conditions
    result = await makeMongoDbService.getDocumentByCustomAggregation([
      { $match: matchCondition },
      { $sort: sortCriteria },
      //   { $skip: skip },
      //   { $limit: pageSize },
    ]);
    console.log(result);
    // Get total order count
    orderCount = await makeMongoDbService.getCountDocumentByQuery(
      matchCondition
    );

    result = result.map((order) => {
      const filteredOrder = { ...order };
      let filteredProducts = order.accounting.cartAccountingList;
      if (req.isVendor) {
        filteredProducts = order.accounting.cartAccountingList.filter(
          (product) => product.vendorId.toString() == req.vendor._id.toString()
        );
      }
      let totalPrice = 0;
      let totalItems = 0;
      for (let product of filteredProducts) {
        totalPrice += product.totalPrice;
        totalItems += product.quantity;
      }

      let totalShippingCost = order.accounting.shippingCost;
      if (req.isVendor) {
        // in this case as we have only one vendor so we can calculate as below
        totalShippingCost =
          totalItems <= 1
            ? totalItems * unitShippingCost_firstProduct
            : unitShippingCost_firstProduct +
              (totalItems - 1) * unitShippingCost_nextProducts;
      }
      totalPrice += totalShippingCost;

      filteredOrder.accounting.cartAccountingList = filteredProducts;
      filteredOrder.vendorNames = filteredOrder.vendorNames
        ? filteredOrder.vendorNames.map((name) => {
            let arr = name.split(" ");
            // Remove undefined and other non-name parts (like vendor ID)
            arr = arr.filter(
              (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
            );
            return arr.join(" ");
          })
        : [];

      filteredOrder.accounting.shippingCost = totalShippingCost;
      filteredOrder.accounting.finalTotal = totalPrice;
      return filteredOrder;
    });

    // Construct meta data for pagination
    meta = {
      pageNumber,
      pageSize,
      totalCount: orderCount,
      prevPage: parseInt(pageNumber) === 1 ? false : true,
      nextPage:
        parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
          ? false
          : true,
      totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
    };

    // Map products and vendors to orders and fetch user details
    result = await Promise.all(
      result.map(async (order) => {
        const filteredOrder = { ...order };
        filteredOrder.accounting.cartAccountingList =
          order.accounting.cartAccountingList.map((product) => {
            const productDetails = products[product.productId.toString()];
            const vendorDetails = vendors[product.vendorId.toString()];
            return {
              ...product,
              productDetails: !productDetails ? {} : productDetails,
              vendorDetails: !vendorDetails ? {} : vendorDetails,
            };
          });

        // Fetch user details by user_id
        const userDetails = await makeMongoDbServiceUser.getDocumentById(
          order.user_id
        );
        filteredOrder.userDetails = userDetails || {}; // Include user details in the order
        return filteredOrder;
      })
    );

    if (searchValue && searchValue.trim() !== "") {
      searchValue = searchValue.toString().toLowerCase();
      console.log(searchValue);
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          // console.log({vendor})
          // console.log()
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let vendor of order.vendors) {
          if (vendor.toString().toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }

    meta.totalCount = result.length;
    meta.nextPage =
      parseInt(result.length) / parseInt(pageSize) <= parseInt(pageNumber)
        ? false
        : true;
    meta.totalPages = Math.ceil(parseInt(result.length) / parseInt(pageSize));

    result = result.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);

    // Return response with orders, meta data, and user details
    return response(
      false,
      null,
      resMessage.success,
      {
        result,
        meta,
        userDetails: req.isVendor ? req.vendor : req.user, // Include vendor details as well
      },
      200
    );
  } catch (error) {
    // Handle errors
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.getPaymentFailed = async (req) => {
  try {
    let meta = {};
    const pageNumber = parseInt(req.query.pageNumber);
    if (isNaN(pageNumber) || pageNumber < 1) {
      throw new Error("Invalid pageNumber");
    }
    const pageSize = 10;
    const skip = pageNumber === 1 ? 0 : parseInt((pageNumber - 1) * pageSize);
    const sortCriteria = { _id: -1 };
    let searchValue = req.query.search || "";
    let orderCount = 0;
    let result = {};
    let matchCondition = {
      $and: [
        { status: "PF" }, // Filter orders with status 'PF' (payment failed)
      ],
    };
    console.log(req.isVendor);
    console.log(req.isAdmin);
    // Ensure the request is from a vendor or admin and fetch vendor ID from the token
    if (!req.isVendor && !req.isAdmin) {
      return response(
        true,
        "User unauthorised to perform this action",
        "",
        null,
        403
      );
    }

    if (req.isVendor) {
      // Add condition to filter orders by the vendor ID
      matchCondition.$and.push({ vendors: req.vendor._id });
    }
    // if (searchValue && searchValue.trim() !== "") {
    //   matchCondition["$and"].push({
    //     $or: [
    //       { payment_status: { $regex: searchValue, $options: "i" } },
    //       { status: { $regex: searchValue, $options: "i" } },
    //       { vendorNames: { $regex: searchValue, $options: "i" } },
    //     ],
    //   });
    // }

    // Fetch products and vendors for further processing
    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    // Fetch orders based on the defined conditions
    result = await makeMongoDbService.getDocumentByCustomAggregation([
      { $match: matchCondition },
      { $sort: sortCriteria },
      //   { $skip: skip },
      //   { $limit: pageSize },
    ]);
    console.log(result);
    // Get total order count
    orderCount = await makeMongoDbService.getCountDocumentByQuery(
      matchCondition
    );

    result = result.map((order) => {
      const filteredOrder = { ...order };
      let filteredProducts = order.accounting.cartAccountingList;
      if (req.isVendor) {
        filteredProducts = order.accounting.cartAccountingList.filter(
          (product) => product.vendorId.toString() == req.vendor._id.toString()
        );
      }
      let totalPrice = 0;
      let totalItems = 0;
      for (let product of filteredProducts) {
        totalPrice += product.totalPrice;
        totalItems += product.quantity;
      }

      let totalShippingCost = order.accounting.shippingCost;
      if (req.isVendor) {
        // in this case as we have only one vendor so we can calculate as below
        totalShippingCost =
          totalItems <= 1
            ? totalItems * unitShippingCost_firstProduct
            : unitShippingCost_firstProduct +
              (totalItems - 1) * unitShippingCost_nextProducts;
      }
      totalPrice += totalShippingCost;

      filteredOrder.accounting.cartAccountingList = filteredProducts;
      filteredOrder.vendorNames = filteredOrder.vendorNames
        ? filteredOrder.vendorNames.map((name) => {
            let arr = name.split(" ");
            // Remove undefined and other non-name parts (like vendor ID)
            arr = arr.filter(
              (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
            );
            return arr.join(" ");
          })
        : [];

      filteredOrder.accounting.shippingCost = totalShippingCost;
      filteredOrder.accounting.finalTotal = totalPrice;
      return filteredOrder;
    });

    // Construct meta data for pagination
    meta = {
      pageNumber,
      pageSize,
      totalCount: orderCount,
      prevPage: parseInt(pageNumber) === 1 ? false : true,
      nextPage:
        parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
          ? false
          : true,
      totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
    };

    // Map products and vendors to orders and fetch user details
    result = await Promise.all(
      result.map(async (order) => {
        const filteredOrder = { ...order };
        filteredOrder.accounting.cartAccountingList =
          order.accounting.cartAccountingList.map((product) => {
            const productDetails = products[product.productId.toString()];
            const vendorDetails = vendors[product.vendorId.toString()];
            return {
              ...product,
              productDetails: !productDetails ? {} : productDetails,
              vendorDetails: !vendorDetails ? {} : vendorDetails,
            };
          });

        // Fetch user details by user_id
        const userDetails = await makeMongoDbServiceUser.getDocumentById(
          order.user_id
        );
        filteredOrder.userDetails = userDetails || {}; // Include user details in the order
        return filteredOrder;
      })
    );

    if (searchValue && searchValue.trim() !== "") {
      searchValue = searchValue.toString().toLowerCase();
      console.log(searchValue);
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          // console.log({vendor})
          // console.log()
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let vendor of order.vendors) {
          if (vendor.toString().toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }
    meta.totalCount = result.length;
    meta.nextPage =
      parseInt(result.length) / parseInt(pageSize) <= parseInt(pageNumber)
        ? false
        : true;
    meta.totalPages = Math.ceil(parseInt(result.length) / parseInt(pageSize));

    result = result.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);

    // Return response with orders, meta data, and user details
    return response(
      false,
      null,
      resMessage.success,
      {
        result,
        meta,
        userDetails: req.isVendor ? req.vendor : req.user, // Include vendor details as well
      },
      200
    );
  } catch (error) {
    // Handle errors
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.getTransactionFailed = async (req) => {
  try {
    let meta = {};
    const pageNumber = parseInt(req.query.pageNumber);
    if (isNaN(pageNumber) || pageNumber < 1) {
      throw new Error("Invalid pageNumber");
    }
    const pageSize = 10;
    const skip = pageNumber === 1 ? 0 : parseInt((pageNumber - 1) * pageSize);
    const sortCriteria = { _id: -1 };
    let searchValue = req.query.search || "";
    let orderCount = 0;
    let result = {};
    let matchCondition = {
      $and: [
        { status: "PF" }, // Filter orders with status 'PF' (payment failed)
      ],
    };
    console.log(req.isVendor);
    console.log(req.isAdmin);
    // Ensure the request is from a vendor or admin and fetch vendor ID from the token
    if (!req.isVendor && !req.isAdmin) {
      return response(
        true,
        "User unauthorised to perform this action",
        "",
        null,
        403
      );
    }

    if (req.isVendor) {
      // Add condition to filter orders by the vendor ID
      matchCondition.$and.push({ vendors: req.vendor._id });
    }
    // if (searchValue && searchValue.trim() !== "") {
    //   matchCondition["$and"].push({
    //     $or: [
    //       { payment_status: { $regex: searchValue, $options: "i" } },
    //       { status: { $regex: searchValue, $options: "i" } },
    //       { vendorNames: { $regex: searchValue, $options: "i" } },
    //     ],
    //   });
    // }

    // Fetch products and vendors for further processing
    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    // Fetch orders based on the defined conditions
    result = await makeMongoDbService.getDocumentByCustomAggregation([
      { $match: matchCondition },
      { $sort: sortCriteria },
      //   { $skip: skip },
      //   { $limit: pageSize },
    ]);
    console.log(result);
    // Get total order count
    orderCount = await makeMongoDbService.getCountDocumentByQuery(
      matchCondition
    );

    result = result.map((order) => {
      const filteredOrder = { ...order };
      let filteredProducts = order.accounting.cartAccountingList;
      if (req.isVendor) {
        filteredProducts = order.accounting.cartAccountingList.filter(
          (product) => product.vendorId.toString() == req.vendor._id.toString()
        );
      }
      let totalPrice = 0;
      let totalItems = 0;
      for (let product of filteredProducts) {
        totalPrice += product.totalPrice;
        totalItems += product.quantity;
      }

      let totalShippingCost = order.accounting.shippingCost;
      if (req.isVendor) {
        // in this case as we have only one vendor so we can calculate as below
        totalShippingCost =
          totalItems <= 1
            ? totalItems * unitShippingCost_firstProduct
            : unitShippingCost_firstProduct +
              (totalItems - 1) * unitShippingCost_nextProducts;
      }
      totalPrice += totalShippingCost;

      filteredOrder.accounting.cartAccountingList = filteredProducts;
      filteredOrder.vendorNames = filteredOrder.vendorNames
        ? filteredOrder.vendorNames.map((name) => {
            let arr = name.split(" ");
            // Remove undefined and other non-name parts (like vendor ID)
            arr = arr.filter(
              (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
            );
            return arr.join(" ");
          })
        : [];

      filteredOrder.accounting.shippingCost = totalShippingCost;
      filteredOrder.accounting.finalTotal = totalPrice;
      return filteredOrder;
    });

    // Construct meta data for pagination
    meta = {
      pageNumber,
      pageSize,
      totalCount: orderCount,
      prevPage: parseInt(pageNumber) === 1 ? false : true,
      nextPage:
        parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
          ? false
          : true,
      totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
    };

    // Map products and vendors to orders and fetch user details
    result = await Promise.all(
      result.map(async (order) => {
        const filteredOrder = { ...order };
        filteredOrder.accounting.cartAccountingList =
          order.accounting.cartAccountingList.map((product) => {
            const productDetails = products[product.productId.toString()];
            const vendorDetails = vendors[product.vendorId.toString()];
            return {
              ...product,
              productDetails: !productDetails ? {} : productDetails,
              vendorDetails: !vendorDetails ? {} : vendorDetails,
            };
          });

        // Fetch user details by user_id
        const userDetails = await makeMongoDbServiceUser.getDocumentById(
          order.user_id
        );
        filteredOrder.userDetails = userDetails || {}; // Include user details in the order
        return filteredOrder;
      })
    );

    if (searchValue && searchValue.trim() !== "") {
      searchValue = searchValue.toString().toLowerCase();
      console.log(searchValue);
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          // console.log({vendor})
          // console.log()
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let vendor of order.vendors) {
          if (vendor.toString().toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }
    meta.totalCount = result.length;
    meta.nextPage =
      parseInt(result.length) / parseInt(pageSize) <= parseInt(pageNumber)
        ? false
        : true;
    meta.totalPages = Math.ceil(parseInt(result.length) / parseInt(pageSize));

    result = result.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);

    // Return response with orders, meta data, and user details
    return response(
      false,
      null,
      resMessage.success,
      {
        result,
        meta,
        userDetails: req.isVendor ? req.vendor : req.user, // Include vendor details as well
      },
      200
    );
  } catch (error) {
    // Handle errors
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.getTransactionCanceled = async (req) => {
  try {
    let meta = {};
    const pageNumber = parseInt(req.query.pageNumber);
    if (isNaN(pageNumber) || pageNumber < 1) {
      throw new Error("Invalid pageNumber");
    }
    const pageSize = 10;
    const skip = pageNumber === 1 ? 0 : parseInt((pageNumber - 1) * pageSize);
    const sortCriteria = { _id: -1 };
    let searchValue = req.query.search || "";
    let orderCount = 0;
    let result = {};
    let matchCondition = {
      $and: [
        { status: "PC" }, // Filter orders with status 'PF' (payment failed)
      ],
    };
    console.log(req.isVendor);
    console.log(req.isAdmin);
    // Ensure the request is from a vendor or admin and fetch vendor ID from the token
    if (!req.isVendor && !req.isAdmin) {
      return response(
        true,
        "User unauthorised to perform this action",
        "",
        null,
        403
      );
    }

    if (req.isVendor) {
      // Add condition to filter orders by the vendor ID
      matchCondition.$and.push({ vendors: req.vendor._id });
    }
    // if (searchValue && searchValue.trim() !== "") {
    //   matchCondition["$and"].push({
    //     $or: [
    //       { payment_status: { $regex: searchValue, $options: "i" } },
    //       { status: { $regex: searchValue, $options: "i" } },
    //       { vendorNames: { $regex: searchValue, $options: "i" } },
    //     ],
    //   });
    // }

    // Fetch products and vendors for further processing
    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    // Fetch orders based on the defined conditions
    result = await makeMongoDbService.getDocumentByCustomAggregation([
      { $match: matchCondition },
      { $sort: sortCriteria },
      //   { $skip: skip },
      //   { $limit: pageSize },
    ]);
    console.log(result);
    // Get total order count
    orderCount = await makeMongoDbService.getCountDocumentByQuery(
      matchCondition
    );

    result = result.map((order) => {
      const filteredOrder = { ...order };
      let filteredProducts = order.accounting.cartAccountingList;
      if (req.isVendor) {
        filteredProducts = order.accounting.cartAccountingList.filter(
          (product) => product.vendorId.toString() == req.vendor._id.toString()
        );
      }
      let totalPrice = 0;
      let totalItems = 0;
      for (let product of filteredProducts) {
        totalPrice += product.totalPrice;
        totalItems += product.quantity;
      }

      let totalShippingCost = order.accounting.shippingCost;
      if (req.isVendor) {
        // in this case as we have only one vendor so we can calculate as below
        totalShippingCost =
          totalItems <= 1
            ? totalItems * unitShippingCost_firstProduct
            : unitShippingCost_firstProduct +
              (totalItems - 1) * unitShippingCost_nextProducts;
      }
      totalPrice += totalShippingCost;

      filteredOrder.accounting.cartAccountingList = filteredProducts;
      filteredOrder.vendorNames = filteredOrder.vendorNames
        ? filteredOrder.vendorNames.map((name) => {
            let arr = name.split(" ");
            // Remove undefined and other non-name parts (like vendor ID)
            arr = arr.filter(
              (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
            );
            return arr.join(" ");
          })
        : [];

      filteredOrder.accounting.shippingCost = totalShippingCost;
      filteredOrder.accounting.finalTotal = totalPrice;
      return filteredOrder;
    });

    // Construct meta data for pagination
    meta = {
      pageNumber,
      pageSize,
      totalCount: orderCount,
      prevPage: parseInt(pageNumber) === 1 ? false : true,
      nextPage:
        parseInt(orderCount) / parseInt(pageSize) <= parseInt(pageNumber)
          ? false
          : true,
      totalPages: Math.ceil(parseInt(orderCount) / parseInt(pageSize)),
    };

    // Map products and vendors to orders and fetch user details
    result = await Promise.all(
      result.map(async (order) => {
        const filteredOrder = { ...order };
        filteredOrder.accounting.cartAccountingList =
          order.accounting.cartAccountingList.map((product) => {
            const productDetails = products[product.productId.toString()];
            const vendorDetails = vendors[product.vendorId.toString()];
            return {
              ...product,
              productDetails: !productDetails ? {} : productDetails,
              vendorDetails: !vendorDetails ? {} : vendorDetails,
            };
          });

        // Fetch user details by user_id
        const userDetails = await makeMongoDbServiceUser.getDocumentById(
          order.user_id
        );
        filteredOrder.userDetails = userDetails || {}; // Include user details in the order
        return filteredOrder;
      })
    );

    if (searchValue && searchValue.trim() !== "") {
      searchValue = searchValue.toString().toLowerCase();
      console.log(searchValue);
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          // console.log({vendor})
          // console.log()
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let vendor of order.vendors) {
          if (vendor.toString().toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }
    meta.totalCount = result.length;
    meta.nextPage =
      parseInt(result.length) / parseInt(pageSize) <= parseInt(pageNumber)
        ? false
        : true;
    meta.totalPages = Math.ceil(parseInt(result.length) / parseInt(pageSize));

    result = result.slice((pageNumber - 1) * pageSize, pageNumber * pageSize);

    // Return response with orders, meta data, and user details
    return response(
      false,
      null,
      resMessage.success,
      {
        result,
        meta,
        userDetails: req.isVendor ? req.vendor : req.user, // Include vendor details as well
      },
      200
    );
  } catch (error) {
    // Handle errors
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.getByDate = async (req) => {
  try {
    let meta = {};

    // Ensure the request is from a vendor or admin and fetch vendor ID from the token
    if (!req.isVendor && !req.isAdmin) {
      return response(
        true,
        "User unauthorised to perform this action",
        "",
        null,
        403
      );
    }

    const startDateParts = req.query.startDate.split("-");
    const startDate = new Date(
      startDateParts[2],
      startDateParts[1] - 1,
      startDateParts[0],
      18,
      30,
      0,
      0
    );

    const endDateParts = req.query.endDate.split("-");
    const endDate = new Date(
      endDateParts[2],
      endDateParts[1] - 1,
      endDateParts[0],
      18,
      30,
      0,
      0
    );

    let orderCount = 0;
    let result = [];

    let matchCondition = {
      $and: [
        {
          createdAt: {
            $gte: startDate,
            $lte: endDate,
          },
        },
      ],
    };

    // Add status filter only if status is provided
    if (req.query && req.query.status) {
      matchCondition.$and.push({
        status: req.query.status,
      });
    }

    if (req.isVendor) {
      // Add condition to filter orders by the vendor ID
      matchCondition.$and.push({ vendors: req.vendor._id });
    }

    let products = await makeMongoDbServiceProduct.getDocumentByQuery({
      status: { $ne: "D" },
    });
    products = products.reduce(
      (obj, item) => ((obj[item._id] = item), obj),
      {}
    );

    let vendors = await makeMongoDbServiceVendor.getDocumentByQuery({
      status: { $ne: "D" },
    });
    vendors = vendors.reduce((obj, item) => ((obj[item._id] = item), obj), {});

    result = await makeMongoDbService.getDocumentByCustomAggregation([
      { $match: matchCondition },
    ]);

    result = await Promise.all(
      result.map(async (order) => {
        const filteredOrder = { ...order };
        let filteredProducts = filteredOrder.accounting.cartAccountingList;
        if (req.isVendor) {
          filteredProducts = order.accounting.cartAccountingList.filter(
            (product) =>
              product.vendorId.toString() == req.vendor._id.toString()
          );
        }

        let totalPrice = 0;
        let totalItems = 0;
        for (let product of filteredProducts) {
          totalPrice += product.totalPrice;
          totalItems += product.quantity;
        }
        let totalShippingCost = order.accounting.shippingCost;
        if (req.isVendor) {
          // Calculate shipping cost for vendor
          totalShippingCost =
            totalItems <= 1
              ? totalItems * unitShippingCost_firstProduct
              : unitShippingCost_firstProduct +
                (totalItems - 1) * unitShippingCost_nextProducts;
        }
        totalPrice += totalShippingCost;

        filteredOrder.vendorNames = filteredOrder.vendorNames
          ? filteredOrder.vendorNames.map((name) => {
              let arr = name.split(" ");
              // Remove undefined and other non-name parts (like vendor ID)
              arr = arr.filter(
                (part) => part !== "undefined" && !part.match(/[a-f0-9]{24}/)
              );
              return arr.join(" ");
            })
          : [];

        filteredOrder.accounting.shippingCost = totalShippingCost;
        filteredOrder.accounting.finalTotal = totalPrice;
        filteredOrder.accounting.cartAccountingList = filteredProducts.map(
          (product) => {
            const productDetails = products[product.productId.toString()];
            const vendorDetails = vendors[product.vendorId.toString()];
            return {
              ...product,
              productDetails: !productDetails ? {} : productDetails,
              vendorDetails: !vendorDetails ? {} : vendorDetails,
            };
          }
        );

        // Fetch user details by user_id
        const userDetails = await makeMongoDbServiceUser.getDocumentById(
          order.user_id
        );
        filteredOrder.userDetails = userDetails || {};
        return filteredOrder;
      })
    );

    if (req.query && req.query.search && req.query.search != "") {
      let searchValue = req.query.search.toString().toLowerCase();
      result = result.filter((order) => {
        if (
          searchValue == order._id.toString() ||
          searchValue == order.payment_status ||
          searchValue == order.status
        ) {
          return true;
        }

        if (
          order.userDetails.first_name &&
          order.userDetails.last_name &&
          (order.userDetails.first_name + " " + order.userDetails.last_name)
            .toLowerCase()
            .includes(searchValue)
        ) {
          return true;
        }

        if (
          order.userDetails.email &&
          order.userDetails.email.toLowerCase().includes(searchValue)
        ) {
          return true;
        }

        let isTrue = false;
        for (let vendor of order.vendorNames) {
          if (vendor.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let vendor of order.vendors) {
          if (vendor.toString().toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        isTrue = false;
        for (let product of order.accounting.cartAccountingList) {
          if (product.productName.toLowerCase().includes(searchValue)) {
            isTrue = true;
            break;
          }
        }
        if (isTrue) return true;

        return false;
      });
    }

    meta = {
      totalCount: result.length,
    };

    return response(
      false,
      null,
      resMessage.success,
      {
        meta,
        result,
      },
      200
    );
  } catch (error) {
    console.log(error);
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.update = async (req) => {
  try {
    let isorder = await makeMongoDbService.getDocumentById(req.body.order_id);

    if (!isorder) {
      return response(true, resMessage.orderNotFound, null, [], 404);
    }
    const orderData = req.body;
    const updatedOrder = await makeMongoDbService.findOneAndUpdateDocument(
      { _id: req.body.order_id },
      orderData
    );

    return response(false, resMessage.orderUpdated, null, updatedOrder, 200);
  } catch (error) {
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.delete = async (req) => {
  try {
    let isorder = await makeMongoDbService.getDocumentById(req.body.order_id);
    if (!isorder) {
      return response(true, resMessage.orderNotFound, null, [], 404);
    }
    const updatedOrder = await makeMongoDbService.findOneAndUpdateDocument(
      { _id: req.body.order_id },
      { status: "D" }
    );

    return response(
      false,
      "Order Delete Successfully",
      null,
      updatedOrder,
      200
    );
  } catch (error) {
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.cancel = async (req) => {
  try {
    let isorder = await makeMongoDbService.getDocumentById(req.body.order_id);
    if (!isorder) {
      return response(true, resMessage.orderNotFound, null, [], 404);
    }
    if (isorder.status == "S" || isorder.status == "R") {
      return response(
        true,
        "Cannot cancel a order which is already shipped or delivered",
        null,
        [],
        400
      );
    }
    const updatedOrder = await makeMongoDbService.findOneAndUpdateDocument(
      { _id: req.body.order_id },
      { status: "CL" }
    );

    const orderDetails = await makeMongoDbService.getSingleDocumentById(
      req.body.order_id
    );
    const userDetails = await makeMongoDbServiceUser.getSingleDocumentById(
      orderDetails.user_id
    );
    const message = getCancelOrderMessage(orderDetails);
    await sendEmail(
      userDetails.email,
      "[Dr Jack's] Order Cancellation Confirmation",
      message
    );

    return response(
      false,
      "Order Cancelled Successfully",
      null,
      updatedOrder,
      200
    );
  } catch (error) {
    throw response(true, null, error.message, error.stack, 500);
  }
};

exports.addTrackingDetails = async (req) => {
  try {
    if (req.isVendor || req.isAdmin) {
      let isorder = await makeMongoDbService.getDocumentById(req.body.order_id);
      if (!isorder) {
        return response(true, resMessage.orderNotFound, null, [], 404);
      }
      if (
        req.isVendor &&
        !isorder.vendors
          .map((id) => id.toString())
          .includes(req.vendor._id.toString())
      ) {
        return response(true, null, resMessage.failed, [], 403);
      }

      const order = isorder;
      order.status = "S";
      order.trackingDetails = {
        tracking_number: req.body.tracking_number,
        tracking_link: req.body.tracking_link,
        remarks: req.body.remarks,
        carrier: req.body.carrier,
        delivery_date: req.body.delivery_date,
        email_attachment: Array.isArray(req.body.email_attachment)
          ? req.body.email_attachment
          : [],
      };
      const updatedOrder = await makeMongoDbService.findOneAndUpdateDocument(
        { _id: req.body.order_id },
        order
      );

      const user = await makeMongoDbServiceUser.getDocumentById(order.user_id);
      const message = getAddShippingMessage(order);
      await sendEmailWithAttachment(
        user.email,
        "[Dr Jack's] Order is shipped",
        message,
        order.trackingDetails.email_attachment,
        true
      );

      return response(false, resMessage.orderUpdated, null, updatedOrder, 200);
    }
    return response(true, null, resMessage.failed, [], 403);
  } catch (error) {
    console.log(error.message);
    return response(true, null, error.message, error.stack, 500);
  }
};

function getAddShippingMessage(order) {
  const formattedDate = order.trackingDetails.delivery_date
    ? moment(order.trackingDetails.delivery_date).format("MM/DD/YYYY")
    : "-";

  const productList = order.accounting.cartAccountingList.map((product) => {
    return `
    <tr>
              <td style="width: 20%;">
                <p style="font-weight: 600; margin: 0; ">
                Title:
                </p>
                </td>
                <td>
              <p style="margin: 0;">${product.productName}</p>
            </td>
            </tr>
            <tr>
              <td style="width: 20%;">
                <p style="font-weight: 600; margin: 0; ">
                Unit Price:
                </p>
                </td>
                <td>
              <p style="margin: 0;">$${product.unitPrice}</p>
            </td>
            </tr>
			
            <tr>
            <td style="width: 20%;">
              <p style="font-weight: 600; margin: 0; ">
              Quantity:
              </p>
              </td>
              <td>
            <p style="margin: 0;">${product.quantity}</p>
          </td>
          </tr>
          <tr>
          <td style="width: 20%;">
            <p style="font-weight: 600; margin: 0; ">
            Total Price:
            </p>
            </td>
            <td>
          <p style="margin: 0;">$${product.totalPrice}</p>
        </td>
        </tr>
			
      
      `;
  });
  return `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Payment Completed</title>
    </head>
    <body>
      <section>
      <div class="companyLogo">
      <img src="https://drjacks.coffee/static/media/logo.caf7bd2d66fa6b49d6b2.png"/ width="10%">
    </div>
        <div>
          <p>Dear customer,</p>
          <p>Your order is placed for shipping. Please find the shipping details of your order below: </p>
          <table style="width: 500px">
            <tr>
              <td style="width:20%">
                <p style="font-weight: 600; margin: 0; ">
                Order Id:
                </p>
                </td>
                <td>
              <p style="margin: 0;">${order.orderNumber}</p>
            </td>
            </tr>
            <h4>Products: </h4>
            ${productList.join("")}
            <br>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Shipping Address:
              </p>
            </td>
            <td><p style="margin: 0; ">${order.shippingAddress}</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Billing Address:
              </p>
            </td>
            <td><p style="margin: 0; ">${order.billingAddress}</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Shipping Cost:
              </p>
            </td>
            <td><p style="margin: 0; ">$${
              order.accounting.shippingCost
            }</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Total Price:
              </p>
            </td>
            <td><p style="margin: 0; ">$${order.accounting.finalTotal}</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Tracking Number:
              </p>
            </td>
            <td><p style="margin: 0; ">${
              order.trackingDetails.tracking_number || "-"
            }</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Tracking Link:
              </p>
            </td>
            <td><p style="margin: 0; ">${
              order.trackingDetails.tracking_link || "-"
            }</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Remarks:
              </p>
            </td>
            <td><p style="margin: 0; ">${
              order.trackingDetails.remarks || "-"
            }</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Tracking carrier:
              </p>
            </td>
            <td><p style="margin: 0; ">${
              order.trackingDetails.carrier || "-"
            }</p></td>
          </tr>
          <tr>
            <td style="width:20%">
              <p style="font-weight: 600; margin: 0;">
              Delivery Date:
              </p>
            </td>
            <td><p style="margin: 0; ">${formattedDate || "-"}</p></td>
          </tr>
          </table>
          </div>
      
    </section>
  </body>
</html>
	`;
}

{
  /* function getAddShippingMessage(order) {
  return `
		Dear customer,<br>
		Your order is placed for shipping. Please find the shipping details of your order below: 
        <br>
		<h4>Order id:</h4> ${order.orderNumber}
		<h4>Shipping Address:</h4> ${order.shippingAddress}
		<h4>Billing Address:</h4> ${order.billingAddress}
		<h4>Shipping Cost:</h4> ${order.accounting.shippingCost}
		<h4>Final Price:</h4> $ ${order.accounting.finalTotal}
		<h4>Tracking Number:</h4> ${order.trackingDetails.tracking_number}
		<h4>Tracking Link:</h4> ${order.trackingDetails.tracking_link}
		<h4>Remarks:</h4> ${order.trackingDetails.remarks}
		<h4>Tracking carrier:</h4> ${order.trackingDetails.carrier}
		<h4>Delivery Date:</h4> ${order.trackingDetails.delivery_date}
	`;
} */
}

function getCancelOrderMessage(order) {
  const productList = order.accounting.cartAccountingList.map((product) => {
    return `<li>
			Title: ${product.productName} <br>
			Unit Price: $ ${product.unitPrice} <br>
			Quantity: ${product.quantity} <br>
			Total Price: $ ${product.totalPrice} <br>
		</li>`;
  });
  return `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Order Cancellation</title>
    </head>
    <body>
      <section>
        <div class="companyLogo">
          <img src="https://drjacks.coffee/static/media/logo.caf7bd2d66fa6b49d6b2.png" width="10%">
        </div>
        <div>
          <p>Dear Customer,</p>
          <p>We have received your request to cancel the order with the details below.</p>
          <table style="width: 500px">
            <tr>
              <td style="width: 20%;">
                <p style="font-weight: 600; margin: 0;">Order ID:</p>
              </td>
              <td>
                <p style="margin: 0;">${order.orderNumber}</p>
              </td>
            </tr>
            <tr>
              <td style="width: 20%;">
                <p style="font-weight: 600; margin: 0;">Total Amount:</p>
              </td>
              <td>
                <p style="margin: 0;">$ ${order.accounting.finalTotal}</p>
              </td>
            </tr>
          </table>
          <br>
          <h4>Products List:</h4>
          <ul>
            ${productList.join("")}
          </ul>
        </div>
      </section>
    </body>
  </html>
	`;
}
