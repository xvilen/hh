const { response } = require("../../../helpers/common");
const { verifyPayment } = require("../../../services/payment");
const { default: mongoose } = require("mongoose");
const { Order } = require("../../../models/order.model");
const { User } = require("../../../models/user.model");
const { Vendor } = require("../../../models/vendor.model");
const { sendEmail } = require("../../../services/email");

const makeMongoDbServiceOrder = require("../../../services/mongoDbService")({
  model: Order,
});
const makeMongoDbServiceUser = require("../../../services/mongoDbService")({
  model: User,
});
const makeMongoDbServiceVendor = require("../../../services/mongoDbService")({
  model: Vendor,
});

// exports.verifyOrder = async (req) => {
// 	try {
// 		let order;
// 		let paymentId = req.body.paymentId;
// 		let order_id = req.body.order_id;
// 		let paymentIntent = await verifyPayment(paymentId);
// 		if (paymentIntent.status === "succeeded") {
// 			order = await makeMongoDbServiceOrder.findOneAndUpdateDocument(
// 				{ _id: order_id },
// 				{ payment_status : "C", paymentIntent }
// 			);
// 			const user = await makeMongoDbServiceUser.getDocumentById(order.user_id);
// 			const message = getPaymentSuccessfulMessage(order);
// 			await sendEmail(user.email,'Payment Successful', message);
// 			return response(false, "Payment received successfully.", null, order,200);
// 		} else {
// 			order = await makeMongoDbServiceOrder.findOneAndUpdateDocument(
// 				{ _id: order_id },
// 				{ payment_status: "P" },
// 				{ payment_status: "PF" }
// 			);
// 			return response(true, "Order payment is incomplete.", null, order,400);
// 		}
// 	} catch (error) {
// 		throw response(true, null, error.message, error.stack,500);
// 	}
// };

exports.verifyOrder = async (req) => {
  let order_id = req.body.order_id;
  let paymentId = req.body.paymentId;
  let shippingAddress = req.body.shippingAddress;
  let billingAddress = req.body.billingAddress;
  const requestBody = {
    payment_status: "C",
    status: "PC",
    paymentId,
  };
  try {
    // Check if order_id is provided and is a valid ObjectId
    if (!order_id || !mongoose.Types.ObjectId.isValid(order_id)) {
      throw {
        status: "BAD_REQUEST",
        message: "The request cannot be fulfilled due to bad syntax",
        data: {
          order_id: "Enter valid order id",
        },
      };
    }

    if (shippingAddress && shippingAddress.length > 0) {
      requestBody.shippingAddress = shippingAddress;
    }

    if (billingAddress && billingAddress.length > 0) {
      requestBody.billingAddress = billingAddress;
    }

    let paymentIntent = await verifyPayment(paymentId);

    let order;
    let user;

    if (paymentIntent.status === "succeeded") {
      order = await makeMongoDbServiceOrder.findOneAndUpdateDocument(
        { _id: order_id },
        requestBody
      );

      // Fetch user details based on user_id
      user = await makeMongoDbServiceUser.getDocumentById(order.user_id);
      if (!user) {
        throw {
          status: "NOT_FOUND",
          message: "User not found",
        };
      }

      // Attach user details to the order object
      order = order.toObject();
      order.user = user;

      console.log("User object before sending email:", user);

      const message = getPaymentSuccessfulMessage(order);
      await sendEmail(user.email, "[Dr Jack's] Payment Successful", message);

      for (let vendorId of order.vendors) {
        let vendor = await makeMongoDbServiceVendor.getDocumentById(vendorId);
        if (!vendor) {
          vendor = await makeMongoDbServiceUser.getDocumentById(vendorId);
        }
        const vendorMessage = getPaymentSuccessfulMessageVendor(order);
        await sendEmail(
          vendor.email,
          "[Dr Jack's] Payment Successful",
          vendorMessage
        );
      }

      return response(
        false,
        "Payment received successfully.",
        null,
        order,
        200
      );
    } else {
      requestBody.payment_status = "PF";
      requestBody.status = "PF";

      order = await makeMongoDbServiceOrder.findOneAndUpdateDocument(
        { _id: order_id },
        requestBody // Update status to "PF" (Payment Failed)
      );

      // Fetch user details based on user_id
      user = await makeMongoDbServiceUser.getDocumentById(order.user_id);

      order = order.toObject();
      order.user = user;

      return response(true, "Order payment failed.", null, order, 400);
    }
  } catch (error) {
    // If an error occurs, update the order status to "PF" and throw an error
    requestBody.payment_status = "PF";
    requestBody.status = "PF";

    const order = await makeMongoDbServiceOrder.findOneAndUpdateDocument(
      { _id: order_id },
      requestBody // Update status to "PF" (Payment Failed)
    );

    console.error(error.message);

    // Fetch user details based on user_id
    const user = await makeMongoDbServiceUser.getDocumentById(order.user_id);

    order = order.toObject();
    order.user = user;

    throw response(true, null, error.message, order, 500);
  }
};

function getPaymentSuccessfulMessage(order) {
  const productList = order.accounting.cartAccountingList.map((product) => {
    return `
    <tr>
              <td style="width: 20%;">
                <p style="font-weight: 600; margin: 0; ">
                Title:
                </p>
                </td>
                <td>
              <p style="margin: 0;">${product.productName}</p>
            </td>
            </tr>
            <tr>
              <td style="width: 20%;">
                <p style="font-weight: 600; margin: 0; ">
                Unit Price:
                </p>
                </td>
                <td>
              <p style="margin: 0;">$${product.unitPrice}</p>
            </td>
            </tr>
			
            <tr>
            <td style="width: 20%;">
              <p style="font-weight: 600; margin: 0; ">
              Quantity:
              </p>
              </td>
              <td>
            <p style="margin: 0;">${product.quantity}</p>
          </td>
          </tr>
          <tr>
          <td style="width: 20%;">
            <p style="font-weight: 600; margin: 0; ">
            Total Price:
            </p>
            </td>
            <td>
          <p style="margin: 0;">$${product.totalPrice}</p>
        </td>
        </tr>
			
      
      `;
  });
  return `
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Payment Completed</title>
    </head>
    <body>
    <section>
    <div class="companyLogo">
    <img src="https://drjacks.coffee/static/media/logo.caf7bd2d66fa6b49d6b2.png"/ width="10%">
  </div>
        <div>
          <p>Dear customer</p>
          <p>Your payment is completed successfully. Please find the details of your order below:</p>
          <table style="width: 500px">
            <tr>
              <td style="width: 20%;">
                <p style="font-weight: 600; margin: 0; ">
                Order Id:
                </p>
                </td>
                <td>
              <p style="margin: 0;">${order.orderNumber}</p>
            </td>
            </tr>
            <h4>Products: </h4>
            ${productList.join("")}
            <br>
          <tr>
            <td style="width: 20%;">
              <p style="font-weight: 600; margin: 0;">
              Shipping Address:
              </p>
            </td>
            <td><p style="margin: 0; ">${order.shippingAddress}</p></td>
          </tr>
          <tr>
            <td style="width: 20%;">
              <p style="font-weight: 600; margin: 0;">
              Billing Address:
              </p>
            </td>
            <td><p style="margin: 0; ">${order.billingAddress}</p></td>
          </tr>
          <td style="width: 20%;">
          <p style="font-weight: 600; margin: 0;">
          Shipping Charges:
          </p>
        </td>
        <td><p style="margin: 0; ">$${order.accounting.shippingCost}</p></td>
      </tr>
          <tr>
            <td style="width: 20%;">
              <p style="font-weight: 600; margin: 0;">
              Final Price:
              </p>
            </td>
            <td><p style="margin: 0; ">$${order.accounting.finalTotal}</p></td>
          </tr>
          </table>
          </div>
          
    </section>
  </body>
</html>
	`;
}

// function getPaymentSuccessfulMessage(order) {
//   return `
// 		Dear customer,<br>
// 		Your payment is completed successfully. Please find the details of your order below:
// 		<h4>Order id:</h4> ${order._id.toString()}
// 		<h4>Shipping Address:</h4> ${order.shippingAddress}
// 		<h4>Billing Address:</h4> ${order.billingAddress}
// 		<h4>Final Price:</h4> $ ${order.accounting.finalTotal}
// 	`;
// }

// function getPaymentSuccessfulMessageVendor(order) {
//   if (!order.user || !order.user.first_name) {
//     console.error("User information is missing in the order object:", order);
//     return "Error: User information is missing.";
//   }
//   return `
//   <!DOCTYPE html>
//   <html lang="en">
//     <head>
//       <meta charset="UTF-8" />
//       <meta name="viewport" content="width=device-width, initial-scale=1.0" />
//       <title>Payment Completed</title>
//     </head>
//     <body>
//       <section>
//       <div class="companyLogo">
//       <img src="https://drjacks.coffee/static/media/logo.caf7bd2d66fa6b49d6b2.png"/ width="10%">
//     </div>
//         <div>
//           <h2 style="font-weight: 400; margin-bottom: 20px">Our Payment Completed -- test</h2>
//           <p>Dear Vendor</p>
//           <br>
//           <p>Payment is completed successfully for an order. Please find the details of your order below:</p>
//           <table style="width: 500px">
//             <tr>
//               <td style="width: 32%;">
//                 <p style="font-weight: 600; margin: 0; ">
//                 Order Id:
//                 </p>
//                 </td>
//                 <td>
//               <p style="margin: 0;">${order.orderNumber}</p>
//             </td>
//             </tr>

//           <tr>
//             <td style="width: 32%;">
//               <p style="font-weight: 600; margin: 0;">
//               Shipping Address:
//               </p>
//             </td>
//             <td><p style="margin: 0; ">${order.shippingAddress}</p></td>
//           </tr>
//           <tr>
//             <td style="width: 32%;">
//               <p style="font-weight: 600; margin: 0;">
//               Billing Address:
//               </p>
//             </td>
//             <td><p style="margin: 0; ">${order.billingAddress}</p></td>
//           </tr>
//           </tr>
//           <td style="width: 32%;">
//           <p style="font-weight: 600; margin: 0;">
//           Shipping Charges:
//           </p>
//         </td>
//         <td><p style="margin: 0; ">$${order.accounting.shippingCost}</p></td>
//       </tr>
//       <tr>
//             <td style="width: 32%;">
//               <p style="font-weight: 600; margin: 0;">
//               Quantity:
//               </p>
//             </td>
//             <td><p style="margin: 0; ">$ ${order.accounting.cartAccountingList.quantity}</p></td>
//           </tr>
//           <tr>
//             <td style="width: 32%;">
//               <p style="font-weight: 600; margin: 0;">
//               Total Price:
//               </p>
//             </td>
//             <td><p style="margin: 0; ">$ ${order.accounting.finalTotal}</p></td>
//           </tr>
//           <div class="customerDetails">
//           <p>Customer Details: </p>
//           </div>
//           <tr>
//               <td style="width: 32%;">
//                 <p style="font-weight: 600; margin: 0; ">
//                 Full Name:
//                 </p>
//                 </td>
//                 <td>
//               <p style="margin: 0;">${order.user.first_name} ${order.user.last_name}</p>
//             </td>
//             </tr>
//             <tr>
//               <td style="width: 32%;">
//                 <p style="font-weight: 600; margin: 0; ">
//                 Email:
//                 </p>
//                 </td>
//                 <td>
//               <p style="margin: 0;">${order.user.email}</p>
//             </td>
//             </tr>
//             <tr>
//               <td style="width: 32%;">
//                 <p style="font-weight: 600; margin: 0; ">
//                 Phone Number:
//                 </p>
//                 </td>
//                 <td>
//               <p style="margin: 0;">${order.user.phone_number}</p>
//             </td>
//             </tr>
//           </table>
//           </div>

//     </section>
//   </body>
// </html>
// 	`;
// }

function getPaymentSuccessfulMessageVendor(order) {
  if (!order.user || !order.user.first_name) {
    console.error("User information is missing in the order object:", order);
    return "Error: User information is missing.";
  }

  // Loop through cartAccountingList for products
  let productDetails = order.accounting.cartAccountingList
    .map((item) => {
      return `
      
      <tr>
        <td style="width: 32%; font-weight: 600;">Quantity:</td>
        <td>${item.quantity}</td>
      </tr>
      
      `;
    })
    .join(""); // Join the mapped rows to render them in the email.

  return `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Payment Completed</title>
      </head>
      <body>
        <section>
          <div class="companyLogo">
            <img src="https://drjacks.coffee/static/media/logo.caf7bd2d66fa6b49d6b2.png" width="10%">
          </div>
          <div>
            <h2 style="font-weight: 400; margin-bottom: 20px">Payment Completed</h2>
            <p>Dear Vendor,</p>
            <br>
            <p>Payment has been completed successfully for the following order. Please find the details of your order below:</p>
            <table style="width: 500px">
              <tr>
                <td style="width: 32%; font-weight: 600;">Order Id:</td>
                <td>${order.orderNumber}</td>
              </tr>
              <tr>
                <td style="width: 32%; font-weight: 600;">Shipping Address:</td>
                <td>${order.shippingAddress}</td>
              </tr>
              <tr>
                <td style="width: 32%; font-weight: 600;">Billing Address:</td>
                <td>${order.billingAddress}</td>
              </tr>
              <tr>
                <td style="width: 32%; font-weight: 600;">Shipping Charges:</td>
                <td>$${order.accounting.shippingCost}</td>
              </tr>
              ${productDetails} <!-- This includes the product name, quantity, unit price, and total price for each product -->
              <tr>
                <td style="width: 32%; font-weight: 600;">Total Price:</td>
                <td>$${order.accounting.finalTotal}</td>
              </tr>
            </table>

            <div class="customerDetails">
              <p>Customer Details:</p>
              <table style="width: 500px">
                <tr>
                  <td style="width: 32%; font-weight: 600;">Full Name:</td>
                  <td>${order.user.first_name} ${order.user.last_name}</td>
                </tr>
                <tr>
                  <td style="width: 32%; font-weight: 600;">Email:</td>
                  <td>${order.user.email}</td>
                </tr>
                <tr>
                  <td style="width: 32%; font-weight: 600;">Phone Number:</td>
                  <td>${order.user.phone_number}</td>
                </tr>
              </table>
            </div>
          </div>
        </section>
      </body>
    </html>
  `;
}

// function getPaymentSuccessfulMessageVendor(order) {
//   return `
// 		Dear Vendor,<br>
// 		Payment is completed successfully for an order. Please find the details of your order below:
// 		<h4>Order id:</h4> ${order._id.toString()}
// 		<h4>Shipping Address:</h4> ${order.shippingAddress}
// 		<h4>Billing Address:</h4> ${order.billingAddress}
// 		<h4>Final Price:</h4> $ ${order.accounting.finalTotal}
// 	`;
// }
